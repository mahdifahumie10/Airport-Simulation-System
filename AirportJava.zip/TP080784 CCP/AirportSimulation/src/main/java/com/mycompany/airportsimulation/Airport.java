package com.mycompany.airportsimulation;

import java.util.*;

public class Airport {
    private final Gate[] gates;
    private final Object runwayLock = new Object();
    private final RefuelTruck truck = new RefuelTruck();

    // limit for planes on airport grounds (including runway) 
    private static final int MAX_ON_GROUND = 3;
    private int onGroundCount = 0; // includes runway + gates when plane is on the airport grounds

    // landing queue (normal + emergency prioritized)
    private final LinkedList<Plane> landingQueue = new LinkedList<>();

    // Runway status (true when occupied)
    private boolean runwayBusy = false;

    // Statistics
    private final List<Long> landingWaits = new ArrayList<>();
    private int planesServed = 0;
    private int passengersBoarded = 0;

    public Airport(int numGates) {
        this.gates = new Gate[numGates];
        for (int i = 0; i < numGates; i++) gates[i] = new Gate(i + 1);
    }

    // ---------------- Landing request (normal) ----------------
    public void requestLanding(Plane plane) throws InterruptedException {
        long requestTime = System.currentTimeMillis();
        synchronized (this) {
            addToLandingQueue(plane);
            while (true) {
                // plane can land if: it's at head of queue or emergency rules, runway free, and grounds capacity allows
                Plane head = landingQueue.peekFirst();
                boolean amIHead = (head == plane);
                boolean runwayFree = !runwayBusy;
                boolean groundsOk = onGroundCount < MAX_ON_GROUND;

                if (amIHead && runwayFree && groundsOk) {
                    // grant permission: occupy runway and increment onGroundCount (plane considered on grounds)
                    runwayBusy = true;
                    onGroundCount++;
                    landingQueue.removeFirst();
                    long startLanding = System.currentTimeMillis();
                    landingWaits.add(startLanding - requestTime);
                    System.out.println("Thread-ATC : ATC: Landing permission granted for Plane-" + plane.getPlaneId());
                    return;
                } else {
                    // wait until something changes (runway freed, gate freed, or plane becomes head)
                    wait();
                }
            }
        }
    }

    // ---------------- Emergency landing request ----------------
    // Emergency planes get priority: if gates full or onGroundCount full, preempt simplest policy: free first gate
    public void requestEmergencyLanding(Plane plane) throws InterruptedException {
        long requestTime = System.currentTimeMillis();
        synchronized (this) {
            addToLandingQueuePriority(plane); // insert emergency at front among non-emergencies
            while (true) {
                Plane head = landingQueue.peekFirst();
                boolean amIHead = (head == plane);
                boolean runwayFree = !runwayBusy;
                boolean groundsOk = onGroundCount < MAX_ON_GROUND;

                if (amIHead && runwayFree && groundsOk) {
                    // normal grant to start landing
                    runwayBusy = true;
                    onGroundCount++;
                    landingQueue.removeFirst();
                    long startLanding = System.currentTimeMillis();
                    landingWaits.add(startLanding - requestTime);
                    System.out.println("Thread-ATC : ATC: EMERGENCY landing permission granted for Plane-" + plane.getPlaneId());
                    return;
                } else if (amIHead && (runwayFree && !groundsOk)) {
                    // runway free but we hit MAX_ON_GROUND -> need to free a gate (preempt)
                    // Find a gate to preempt: simple policy pick first occupied gate
                    Gate toPreempt = null;
                    for (Gate g : gates) {
                        if (g.isOccupied()) { toPreempt = g; break; }
                    }
                    if (toPreempt != null) {
                        int displaced = toPreempt.getOccupiedBy();
                        System.out.println("Thread-ATC : ATC: Preempting Gate-" + toPreempt.getIndex()
                                + " (displacing Plane-" + displaced + ") for emergency Plane-" + plane.getPlaneId());
                        toPreempt.forceRelease(); // preempt occupying plane
                        // now proceed to occupy runway and landing
                        runwayBusy = true;
                        // onGroundCount remains same because preempted plane forced to leave -> we will treat as replacement
                        // remove emergency from queue and record wait
                        landingQueue.removeFirst();
                        long startLanding = System.currentTimeMillis();
                        landingWaits.add(startLanding - requestTime);
                        // NOTE: the displaced plane should detect preemption via gate status and leave
                        return;
                    } else {
                        // No gate occupied somehow -> wait
                        wait();
                    }
                } else {
                    wait();
                }
            }
        }
    }

    // Called by plane when it finishes landing and vacates the runway (but still on ground at a gate)
    public void finishedLanding(Plane plane) {
        synchronized (this) {
            runwayBusy = false;
            System.out.println("Thread-" + Thread.currentThread().getName() + " : Plane-" + plane.getPlaneId() + " : Landed and runway freed.");
            notifyAll();
        }
    }

    // ---------------- Gate assignment ----------------
    // Caller assumes it already holds a landing permission and onGroundCount has been incremented
    public Gate assignGate(Plane plane) throws InterruptedException {
        synchronized (this) {
            while (true) {
                for (Gate g : gates) {
                    if (!g.isOccupied()) {
                        g.occupy(plane.getPlaneId());
                        System.out.println("Thread-ATC : ATC: Gate-" + g.getIndex() + " assigned for Plane-" + plane.getPlaneId());
                        return g;
                    }
                }
                // No gate free; since small airport has no ground waiting area, plane must wait off-airport (we'll simulate by waiting)
                System.out.println("Thread-ATC : ATC: No gates available for Plane-" + plane.getPlaneId() + ". Waiting for gate.");
                wait();
            }
        }
    }

    // Release gate when plane leaves (voluntarily)
    public void releaseGate(Gate gate, Plane plane) {
        synchronized (this) {
            if (gate.getOccupiedBy() == plane.getPlaneId()) {
                gate.release();
                // plane will soon leave the airport (onGroundCount decremented on takeoff)
                System.out.println("Thread-ATC : ATC: Plane-" + plane.getPlaneId() + " released Gate-" + gate.getIndex());
                notifyAll();
            } else {
                // gate was preempted earlier; nothing to do
                System.out.println("Thread-ATC : ATC: Gate-" + gate.getIndex() + " was not owned by Plane-" + plane.getPlaneId()
                        + " at release time (likely preempted).");
            }
        }
    }

    // ---------------- Takeoff ----------------
    public void requestTakeoff(Plane plane) throws InterruptedException {
        synchronized (this) {
            while (runwayBusy) wait();
            // ensure that runway usage doesn't exceed MAX_ON_GROUND: during takeoff, plane is counted as on ground until finishedTakeoff
            runwayBusy = true;
            System.out.println("Thread-ATC : ATC: Takeoff permission granted for Plane-" + plane.getPlaneId());
        }
    }

    public void finishedTakeoff(Plane plane) {
        synchronized (this) {
            runwayBusy = false;
            planesServed++;
            passengersBoarded += plane.getPassengersOnBoard();
            if (onGroundCount > 0) onGroundCount--; // plane left grounds, reduces planes on ground count if it was more than 0.
            System.out.println("Thread-ATC : ATC: Plane-" + plane.getPlaneId() + " took off and left airport. Runway free.");
            notifyAll();
        }
    }

    // ---------------- Refuel truck access ----------------
    public RefuelTruck getRefuelTruck() { //Getter 
        return truck;
    }

    // ---------------- Landing queue helpers ----------------
    private void addToLandingQueue(Plane p) {
        landingQueue.addLast(p);
        System.out.println("Thread-" + Thread.currentThread().getName() + " : Plane-" + p.getPlaneId()
                + ": Requesting landing (emergency=" + p.isEmergency() + "). Queue size: " + landingQueue.size());
    }

    private void addToLandingQueuePriority(Plane p) {
        // place in front of non-emergency planes but keep FIFO among emergencies
        int idx = 0;
        while (idx < landingQueue.size() && landingQueue.get(idx).isEmergency()) idx++;
        landingQueue.add(idx, p);
        System.out.println("Thread-" + Thread.currentThread().getName() + " : Plane-" + p.getPlaneId()
                + ": Requesting EMERGENCY landing. Queue size: " + landingQueue.size());
    }

    // ---------------- Statistics & final sanity check ----------------
    public synchronized void printStatistics() {
        // Sanity: all gates empty?
        boolean allEmpty = true;
        for (Gate g : gates) if (g.isOccupied()) allEmpty = false;
        System.out.println("Sanity check - All gates empty? " + (allEmpty ? "YES" : "NO"));

        if (!landingWaits.isEmpty()) {
            long max = Collections.max(landingWaits);
            long min = Collections.min(landingWaits);
            double avg = landingWaits.stream().mapToLong(Long::longValue).average().orElse(0.0);
            System.out.printf("Landing wait times (ms) - Max: %d, Min: %d, Avg: %.1f%n", max, min, avg);
        } else {
            System.out.println("No landing wait times recorded.");
        }

        System.out.println("Number of planes served: " + planesServed);
        System.out.println("Total passengers boarded: " + passengersBoarded);
    }
}

