package com.mycompany.airportsimulation;

public class Gate {
    private final int index;
    private boolean occupied;
    private int occupiedBy; // plane id occupying or 0 if free

    public Gate(int index) {
        this.index = index;
        this.occupied = false;
        this.occupiedBy = 0;
    }

    public int getIndex() { return index; }

    public synchronized boolean isOccupied() { return occupied; } // Getters

    public synchronized int getOccupiedBy() { return occupiedBy; }

    public synchronized void occupy(int planeId) {
        this.occupied = true;
        this.occupiedBy = planeId;
    }

    // release normally (plane leaves)
    public synchronized void release() {
        this.occupied = false;
        this.occupiedBy = 0;
    }

    // force release used for preemption (emergency)
    public synchronized void forceRelease() {
        this.occupied = false;
        int displaced = this.occupiedBy;
        this.occupiedBy = 0;
        System.out.println("Thread-ATC : ATC: Gate-" + index + " forcibly freed (displaced Plane-" + displaced + ").");
    }
}


