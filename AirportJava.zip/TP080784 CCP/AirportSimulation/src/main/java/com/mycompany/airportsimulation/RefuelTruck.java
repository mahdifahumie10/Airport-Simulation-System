package com.mycompany.airportsimulation;

public class RefuelTruck {
    // only one plane refuels at a time because method is synchronized
    public synchronized void refuel(int planeId, int gateIndex) throws InterruptedException {
        System.out.println("Refuel Truck: Starting refuel for Plane-" + planeId + " at Gate-" + gateIndex);
        Thread.sleep(900); // simulate refuelling time
        System.out.println("Refuel Truck: Completed refuel for Plane-" + planeId);
        // notify not required here; airport controls waiting for truck by synchronized method on truck
    }
}


