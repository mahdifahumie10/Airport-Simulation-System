package com.mycompany.airportsimulation;

import java.util.*;

public class AirportSimulation {
    public static void main(String[] args) throws InterruptedException {
        final int GATES = 2;                 // assumption: 2 gates (so runway + 2 gates = max 3 on grounds)
        final int TOTAL_PLANES = 6;

        Airport airport = new Airport(GATES);
        Random rand = new Random();

        System.out.println("=== Asia Pacific Airport Simulation START ===\n");

        // Start Plane-1 and Plane-2 quickly so they occupy the two gates
        Plane p1 = new Plane(1, 50, airport, false);
        Plane p2 = new Plane(2, 50, airport, false);
        p1.start();
        Thread.sleep(300);
        p2.start();

        // Give them time to occupy gates
        Thread.sleep(800);

        // Start Plane-3 and Plane-4 which will likely wait (congestion)
        Plane p3 = new Plane(3, 50, airport, false);
        Plane p4 = new Plane(4, 50, airport, false);
        p3.start();
        Thread.sleep(150);
        p4.start();

        // Allow queue to build
        Thread.sleep(800);

        // Start an emergency plane (fuel shortage) -> must get priority
        Plane p5 = new Plane(5, 50, airport, true); // emergency = true
        p5.start();

        // Start remaining plane, arrive randomly to mix things
        Thread.sleep(rand.nextInt(2000));
        Plane p6 = new Plane(6, 50, airport, false);
        p6.start();

        // Wait for all to complete
        p1.join(); p2.join(); p3.join(); p4.join(); p5.join(); p6.join();

        System.out.println("\n=== Simulation complete: ATC printing statistics ===");
        airport.printStatistics(); // Print statistics 
    }
}


