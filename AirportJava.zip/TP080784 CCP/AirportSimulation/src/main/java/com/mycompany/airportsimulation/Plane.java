package com.mycompany.airportsimulation;

import java.util.Random;

public class Plane extends Thread {
    private final int id;
    private final int capacity;            // max passengers (50)
    private final Airport airport;
    private final boolean emergency;       // true if needs emergency landing
    private int passengersOnBoard;
    private final Random rand = new Random();

    public Plane(int id, int capacity, Airport airport, boolean emergency) {
        super("Plane-" + id);
        this.id = id;
        this.capacity = capacity;
        this.airport = airport;
        this.emergency = emergency;
        // random initial passenger count (0..capacity)
        this.passengersOnBoard = rand.nextInt(capacity + 1);
    }

    public int getPlaneId() { return id; }
    public boolean isEmergency() { return emergency; }
    public int getPassengersOnBoard() { return passengersOnBoard; }

    @Override
    public void run() {
        try {
            // Request landing (emergency or normal)
            if (emergency) {
                System.out.println("Thread-" + getName() + " : !! EMERGENCY !! Plane-" + id + " low on fuel. Requesting emergency landing.");
                airport.requestEmergencyLanding(this);
            } else {
                System.out.println("Thread-" + getName() + " : Plane-" + id + " requesting landing.");
                airport.requestLanding(this);
            }

            // Simulate landing on runway (we already were given runway permission in requestLanding)
            System.out.println("Thread-" + getName() + " : Plane-" + id + " is landing on runway...");
            Thread.sleep(400 + rand.nextInt(400)); // landing time
            airport.finishedLanding(this);

            // Coast to gate and request assignment
            Gate myGate = airport.assignGate(this);

            // Docked at gate
            System.out.println("Thread-" + getName() + " : Plane-" + id + " docked at Gate-" + myGate.getIndex());

            // Passengers disembark (simultaneous across planes)
            System.out.println("Thread-" + getName() + " : Plane-" + id + " passengers disembarking...");
            Thread.sleep(300 + rand.nextInt(300));

            // Cleaning and restocking (concurrent)
            System.out.println("Thread-" + getName() + " : Plane-" + id + " cleaning/supplying...");
            Thread.sleep(200 + rand.nextInt(300));

            // Check if we were preempted while at gate
            if (myGate.getOccupiedBy() != id) {
                // We were preempted by an emergency plane; we should leave immediately
                System.out.println("Thread-" + getName() + " : Plane-" + id + " was PREEMPTED at Gate-" + myGate.getIndex() + ". Leaving immediately.");
                // go to runway and take off (emergency departure)
                airport.requestTakeoff(this);
                System.out.println("Thread-" + getName() + " : Plane-" + id + " taking off after preemption...");
                Thread.sleep(300);
                airport.finishedTakeoff(this);
                return;
            }

            // Refuel (shared truck)
            System.out.println("Thread-" + getName() + " : Plane-" + id + " requesting refuel at Gate-" + myGate.getIndex());
            airport.getRefuelTruck().refuel(id, myGate.getIndex());

            // Board new passengers (simulate)
            int newPassengers = rand.nextInt(capacity - passengersOnBoard + 1);
            System.out.println("Thread-" + getName() + " : Plane-" + id + " boarding " + newPassengers + " passengers...");
            Thread.sleep(300 + rand.nextInt(300));
            passengersOnBoard += newPassengers;

            // Undock and coast to runway
            System.out.println("Thread-" + getName() + " : Plane-" + id + " undocking and coasting to runway...");
            Thread.sleep(200 + rand.nextInt(200));

            // Release gate
            airport.releaseGate(myGate, this);

            // Request takeoff
            airport.requestTakeoff(this);
            System.out.println("Thread-" + getName() + " : Plane-" + id + " taking off...");
            Thread.sleep(400 + rand.nextInt(300)); // takeoff time
            airport.finishedTakeoff(this);

            System.out.println("Thread-" + getName() + " : Plane-" + id + " has completed full cycle.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Thread-" + getName() + " : Plane-" + id + " interrupted.");
        }
    }
}
